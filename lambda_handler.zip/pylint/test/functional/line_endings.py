"mixing line endings are not welcome"
# +1: [unexpected-line-ending-format, mixed-line-endings]
CONST = 1
