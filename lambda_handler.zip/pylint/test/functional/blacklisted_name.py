# pylint: disable=missing-docstring

def baz(): # [blacklisted-name]
    pass
